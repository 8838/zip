<?php

class widget_ui_slider extends WP_Widget {
	function __construct(){
		parent::__construct( 'widget_ui_slider', 'DUX 幻灯片', array( 'classname' => 'widget_ui_slider' ) );
	}

	function widget( $args, $instance ) {
		extract( $args );

		// $title  = apply_filters('widget_name', $instance['title']);
		$biao   = isset($instance['biao']) ? $instance['biao'] : '';

		echo $before_widget;

		$inner = '';
		for ($i=1; $i < 6; $i++) { 
	        if( isset($instance['pic0'.$i]) && $instance['pic0'.$i] ){
	        	if( isset($instance['link0'.$i]) && $instance['link0'.$i]  ){
	            	$inner .= '<div class="swiper-slide"><a target="_blank" href="'. $instance['link0'.$i] .'"><img src="'. $instance['pic0'.$i] .'"></a></div>';
	        	}else{
	            	$inner .= '<div class="swiper-slide"><img src="'. $instance['pic0'.$i] .'"></div>';
	        	}
	        }
	    }

	    echo '<div class="swiper-container">
	        <div class="swiper-wrapper">'.$inner.'</div>';
		    if( $biao ) echo '<div class="swiper-pagination"></div>';
	    echo '</div>';

		echo $after_widget;
	}
	function form($instance) {
		$defaults = array( 
			'biao'   => '',
			'pic01'  => get_stylesheet_directory_uri() . '/img/slider01.jpg', 
			'link01' => 'https://themebetter.com',
			'pic02'  => get_stylesheet_directory_uri() . '/img/slider02.jpg', 
			'link02' => 'https://themebetter.com',
			'pic03'  => get_stylesheet_directory_uri() . '/img/slider03.jpg', 
			'link03' => 'https://themebetter.com',
			'pic04'  => '', 
			'link04' => '',
			'pic05'  => '', 
			'link05' => '',
		);
		$instance = wp_parse_args( (array) $instance, $defaults );

?>
		
		<?php for ($i=1; $i < 6; $i++) { ?>
			<p>
				<label>
					图 <?php echo $i ?> 地址（图片宽度360像素）：
					<input class="widefat" id="<?php echo $this->get_field_id('pic0'.$i); ?>" name="<?php echo $this->get_field_name('pic0'.$i); ?>" type="text" value="<?php echo $instance['pic0'.$i]; ?>" />
				</label>
			</p>
			<p>
				<label>
					图 <?php echo $i ?> 链接：
					<input class="widefat" id="<?php echo $this->get_field_id('link0'.$i); ?>" name="<?php echo $this->get_field_name('link0'.$i); ?>" type="text" value="<?php echo $instance['link0'.$i]; ?>" />
				</label>
			</p>
		<?php } ?>

		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['biao'], 'on' ); ?> id="<?php echo $this->get_field_id('biao'); ?>" name="<?php echo $this->get_field_name('biao'); ?>">显示小标
			</label>
		</p>
		

<?php
	}
}