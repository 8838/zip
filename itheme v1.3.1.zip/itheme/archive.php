<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div class="thw-title-wrap">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<h2 class="entry-single-title"><?php $this->archiveTitle(array(
            'category'  =>  _t('<span>Category: </span>%s'),
            'search'    =>  _t('<span>Search: </span>%s'),
            'tag'       =>  _t('<span>Tag: </span>%s'),
            'author'    =>  _t('<span>Author: </span>%s')
        ), '', ''); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
			<div class="main-container">
                <div class="container">
                    <div class="row">
<?php while($this->next()): ?>
					                        <div class="col-lg-4 col-md-12 col-sm-12">
                            <div class="post-grid">
                                <div class="post-grid-view post-grid-view-lg">
                                    <div class="post-grid-image" onclick="window.open('<?php $this->permalink() ?>','_self')">
<?php
preg_match_all("/\<img.*?src\=(\'|\")(.*?)(\'|\")[^>]*>/i", $this->content, $matches);
$imgCount = count($matches[0]);
if($imgCount >= 1){
    $img = $matches[2][0];
echo <<<Html

<img class="img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src={$img}&#38;w=265&#38;h=350&#38;zc=1&#38;q=100">
     
Html;
}else{
echo <<<Html

<img class="img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src=/usr/themes/itheme/images/nopic.png&#38;w=265&#38;h=350&#38;zc=1&#38;q=100">
     
Html;
}
?> 
                                    </div>
									<div class="post-content post-content-overlay" onclick="window.open('<?php $this->permalink() ?>','_self')"> 
                                        <div class="post-header"> 
                                            <span class="category-meta"><?php $this->category(','); ?></span>
                                            <h3 class="entry-post-title">
                                                <a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
                                            </h3>
                                        </div>
                                        <div class="post-meta-footer">
                                            <span class="grid-post-date"><?php $this->date('n月 d,Y'); ?></span>
                                            <span class="grid-post-author">
                                                <a class="button like js-action button--primary button--chromeless" data-action="postlike" data-action-value="23">
	<span class="singlelike button-defaultState icon"><i class="zb-heart-o"></i></span><span class="singlelike button-activeState icon"><i class="zb-heart"></i></span><span class="count"><?php $this->commentsNum('0', '1', '%d'); ?></span></a> 谈论 
												<i style="margin: 0 5px;" class="zb-view"></i><?php echo Postviews($this) ?> 浏览
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php endwhile; ?>
                    </div>
                </div>
            </div>
					<div class="paging">
<?php $this->pageNav('«', '»', 3, '...', array('wrapTag' => 'ul', 'wrapClass' => 'pagination justify-content-center', '' => 'li', 'textTag' => 'span', 'currentClass' => 'active', 'prevClass' => 'prev', 'nextClass' => 'next')) ; ?>
					</div>
	<?php $this->need('footer.php'); ?>
