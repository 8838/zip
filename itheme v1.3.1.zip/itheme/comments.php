<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="comments" class="comments-area">
    <?php $this->comments()->to($comments); ?>
    <?php if($this->allow('comment')): ?>
<div id="<?php $this->respondId(); ?>" class="comment-respond">
	<h3 id="reply-title" class="comment-reply-title">
	<h3 class="title-normal">Leave a comment</h3>
	<small><?php $comments->cancelReply("X"); ?></small></h3>
	<form method="post" action="<?php $this->commentUrl() ?>" id="commentform" class="comment-form" novalidate>
		<p class="comment-notes">
			<span id="email-notes">电子邮件地址不会被公开。</span> 必填项已用<span class="required">*</span>标注
<?php if($this->user->hasLogin()): ?>
    		<p><?php _e('登录身份: '); ?><a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></p>
<?php endif; ?>
		</p>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<textarea id="comment" class="form-control required-field" name="text" rows="8" aria-required="true" required ><?php $this->remember('text'); ?></textarea>
				</div>
			</div>
<?php if($this->user->hasLogin()): ?>
            <?php else: ?>
			<div class="col-md-4">
				<div class="form-group">
					<input id="author" placeholder="Name**" class="form-control" name="author" type="text" value="<?php $this->remember('author'); ?>" required size="30" aria-required="true"/>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<input id="email" placeholder="Email<?php if ($this->options->commentsRequireMail): ?>**<?php endif; ?>" class="form-control" name="mail" type="text" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> size="30" aria-required="true"/>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<input id="email" placeholder="Url" class="form-control" name="url" type="text" value="<?php $this->remember('url'); ?>" size="30" aria-required="true"/>
				</div>
			</div>
<?php endif; ?>
			<div class="col-md-4">
				<div class="form-group">
					<div id="gt_reply">
					</div>
				</div>
			</div>
			<p class="form-submit">
				<input name="submit" type="submit" id="submit" class="btn btn-primary" value="Submit"/>
			</p>
	</div>
		</form>
	<!-- #respond -->
</div>
    <?php else: ?>
    <?php endif; ?>
	

    <?php if ($comments->have()): ?>
<div id="comments" class="comments-area comments-sept">
<ol class="comment-list">
    <?php $comments->listComments(); ?>
</ol>
</div>
    <?php $comments->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
    
    <?php endif; ?>
</div>
