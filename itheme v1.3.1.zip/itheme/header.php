<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>
<meta name="description" content="<?php $this->options->description() ?>">
<link type="image/vnd.microsoft.icon" href="<?php $this->options->themeUrl(); ?>images/favicon.png" rel="shortcut icon"><meta name='robots' content='noindex,follow' />
<link rel='stylesheet' id='bootstrap-css'  href='<?php $this->options->themeUrl(); ?>css/bootstrap.min.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='icons-css'  href='<?php $this->options->themeUrl(); ?>css/icons.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='<?php $this->options->themeUrl(); ?>css/style.css?ver=4.9.10' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css'  href='<?php $this->options->themeUrl(); ?>css/responsive.css?ver=1.1' type='text/css' media='all' />
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/lightbox.css'); ?>">
<script type='text/javascript' src='<?php $this->options->themeUrl(); ?>js/jquery.min.js?ver=4.9.10'></script>
<?php $this->header(); ?>
</head>
<body class="home blog">
	<div class="inner-body-wrap">
		<div class="inner-body container">
			<header class="thw-header header-default">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-md-12 col-sm-12">
							<nav class="navbar navbar-expand-lg thw-navbar-light">
								<a class="thw-logo" href="<?php $this->options->siteUrl(); ?>">
																		<img src="<?php echo $this->options->logoUrl; ?>" data-original="<?php echo $this->options->logoUrl; ?>" alt="<?php $this->options->title(); ?>" />
																	</a>
								<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                                            aria-expanded="false" aria-label="Toggle navigation">
									<span class="thw-navbar-toggler-icon"><i class="zb-menu"></i></span>
                                </button>
                                <div class="collapse navbar-collapse thw-navbar" id="navbarSupportedContent">
								<ul id="menu-menu-1" class="navbar-nav">
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item nav-item"><a class="nav-link" href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a></li>
<?php $this->widget('Widget_Metas_Category_List')->parse('<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item nav-item"><a class="nav-link" href="{permalink}">{name}</a></li>'); ?>
                    <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
                    <?php while($pages->next()): ?>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item nav-item"><a class="nav-link" href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a></li>
                    <?php endwhile; ?>
</ul>                                </div> 
                                <div class="search-link">
                                    <form role="search" method="get" action="<?php $this->options->siteUrl(); ?>">
                                        <button type="button"><i class="zb-search show"></i></button>
                                        <button><i class="zb-close"></i></button>
                                        <div class="search-box">
                                            <input type="search" name="s" id="search" placeholder="搜索...">
                                        </div>
                                    </form>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </header>