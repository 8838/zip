﻿!function(t){"function"==typeof define&&define.amd?define(["jquery"],t):t(window.jQuery||window.Zepto)}(function(t,e){var a,r,n=window,o=t(n),l={threshold:0,failure_limit:0,event:"scroll",effect:"show",effect_params:null,container:n,data_attribute:"original",data_srcset_attribute:"original-srcset",skip_invisible:!0,appear:i,load:i,vertical_only:!1,check_appear_throttle_time:300,url_rewriter_fn:i,no_fake_img_loader:!1,placeholder_data_img:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC",placeholder_real_img:"http://ditu.baidu.cn/yyfm/lazyload/0.0.1/img/placeholder.png"};function i(){}function c(t,e){return(e._$container==o?("innerHeight"in n?n.innerHeight:o.height())+o.scrollTop():e._$container.offset().top+e._$container.height())<=t.offset().top-e.threshold}function f(t,e){return(e._$container==o?o.scrollTop():e._$container.offset().top)>=t.offset().top+e.threshold+t.height()}function _(e,a){var r=0;e.each(function(l,i){var _=e.eq(l);if(!(_.width()<=0&&_.height()<=0||"none"===_.css("display")))if(a.vertical_only)if(f(_,a));else if(c(_,a)){if(++r>a.failure_limit)return!1}else d();else if(f(_,a)||function(e,a){return(a._$container==o?t.fn.scrollLeft?o.scrollLeft():n.pageXOffset:a._$container.offset().left)>=e.offset().left+a.threshold+e.width()}(_,a));else if(c(_,a)||function(e,a){return(a._$container==o?o.width()+(t.fn.scrollLeft?o.scrollLeft():n.pageXOffset):a._$container.offset().left+a._$container.width())<=e.offset().left-a.threshold}(_,a)){if(++r>a.failure_limit)return!1}else d();function d(){_.trigger("_lazyload_appear"),r=0}})}function d(t){return t.filter(function(e){return!t.eq(e).data("_lazyload_loadStarted")})}r=Object.prototype.toString,a=function(t){return r.call(t).replace("[object ","").replace("]","")},t.fn.hasOwnProperty("lazyload")||(t.fn.lazyload=function(e){var r,c,f,s=this;return t.isPlainObject(e)||(e={}),t.each(l,function(r,i){var c=a(e[r]);-1!=t.inArray(r,["threshold","failure_limit","check_appear_throttle_time"])?"String"==c?e[r]=parseInt(e[r],10):"Number"!=c&&(e[r]=i):"container"==r?(e.hasOwnProperty(r)?e[r]==n||e[r]==document?e._$container=o:e._$container=t(e[r]):e._$container=o,delete e.container):!l.hasOwnProperty(r)||e.hasOwnProperty(r)&&c==a(l[r])||(e[r]=i)}),r="scroll"==e.event,f=0==e.check_appear_throttle_time?_:function(t,e){var a,r,n,o,l=0;return function(){a=this,r=arguments;var t=new Date-l;return o||(t>=e?i():o=setTimeout(i,e-t)),n};function i(){o=0,l=+new Date,n=t.apply(a,r),a=null,r=null}}(_,e.check_appear_throttle_time),c=r||"scrollstart"==e.event||"scrollstop"==e.event,s.each(function(a,r){var n=this,o=s.eq(a),l=o.attr("src"),f=o.attr("data-"+e.data_attribute),_=e.url_rewriter_fn==i?f:e.url_rewriter_fn.call(n,o,f),u=o.attr("data-"+e.data_srcset_attribute),h=o.is("img");if(o.data("_lazyload_loadStarted")||l==_)return o.data("_lazyload_loadStarted",!0),void(s=d(s));o.data("_lazyload_loadStarted",!1),h&&!l&&o.one("error",function(){o.attr("src",e.placeholder_real_img)}).attr("src",e.placeholder_data_img),o.one("_lazyload_appear",function(){var a,r=t.isArray(e.effect_params);function l(){a&&o.hide(),h?(u&&o.attr("srcset",u),_&&o.attr("src",_)):o.css("background-image",'url("'+_+'")'),a&&o[e.effect].apply(o,r?e.effect_params:[]),s=d(s)}o.data("_lazyload_loadStarted")||(a="show"!=e.effect&&t.fn[e.effect]&&(!e.effect_params||r&&0==e.effect_params.length),e.appear!=i&&e.appear.call(n,o,s.length,e),o.data("_lazyload_loadStarted",!0),e.no_fake_img_loader||u?(e.load!=i&&o.one("load",function(){e.load.call(n,o,s.length,e)}),l()):t("<img />").one("load",function(){l(),e.load!=i&&e.load.call(n,o,s.length,e)}).attr("src",_))}),c||o.on(e.event,function(){o.data("_lazyload_loadStarted")||o.trigger("_lazyload_appear")})}),c&&e._$container.on(e.event,function(){f(s,e)}),o.on("resize load",function(){f(s,e)}),t(function(){f(s,e)}),this})});
$(function ($) {
   "use strict";

   if ($(window).width() < 991) {
      $(".navbar-nav li a").on("click", function () {
         $(this).parent("li").find(".dropdown-menu").slideToggle();
         $(this).find("i").toggleClass("icon-angle-down fa-angle-down");
      });
   }
	$(document).ready(function(){
	 dropdownOpen();
	});
	function dropdownOpen() {
	 
	 var $dropdownLi = $('li.dropdown');
	 
	 $dropdownLi.mouseover(function() {
	 $(this).addClass('open');
	 }).mouseout(function() {
	 $(this).removeClass('open');
	 });
	}
	
	$("img.lazy").lazyload();


   $(".search-link i.zb-close").on("click", function (event) {
      event.preventDefault()
      $(".search-link i.zb-search").addClass("show");
      $(".search-link form .search-box").removeClass("show");
      $(".search-link i.zb-close").removeClass("show");
   });
   $(".search-link i.zb-search").on("click", function () {
      $(".search-link i.zb-search").removeClass("show");
      $(".search-link form .search-box").addClass("show");
      $(".search-link i.zb-close").addClass("show");
   });

    $(".post-grid-image").each(function() {
        var postcolol = $(this).data('color');
        $(this).css( "background-color", postcolol );      
    });
	jQuery('.openweixin.weixin').on('click',
	function(event) {
		event.preventDefault();
		jQuery('body').toggleClass('weixin-shown');
		jQuery('#login').toggleClass('ajax-auth');
	});
	jQuery('#weixinpopup .closeweixin').on('click',
	function(event) {
		event.preventDefault();
		jQuery('body').removeClass('weixin-shown');
		jQuery('#login').removeClass('ajax-auth');
	});

});
(jQuery),+function(t){var l=jQuery("body"),d={postlike:function(t){var e=t.data();if(!t.hasClass("is-active")){var a=t.find(".count");t.addClass("is-active"),l.addClass("is-loadingApp"),jQuery.ajax({url:zb.admin_url,type:"POST",dataType:"json",data:e,success:function(t){a.html(t.data),l.removeClass("is-loadingApp")}})}}},v=0;jQuery(document).on("click",".js-action",function(t){t.preventDefault();var e=jQuery(this),a=e.data("action");return a&&d[a](e),!1}),window.LEE=d}(jQuery);
jQuery(document).ready(function(t) {
    t(".cd-popup-trigger").on("click",
    function(e) {
        e.preventDefault(),
        t(".cd-popup").addClass("is-visible")
    }),
    t(".cd-popup").on("click",
    function(e) { (t(e.target).is(".cd-popup-close") || t(e.target).is(".cd-popup")) && (e.preventDefault(), t(this).removeClass("is-visible"))
    }),
    t(document).keyup(function(e) {
        "27" == e.which && t(".cd-popup").removeClass("is-visible")
    })
});
//监听滚动条事件
window.onscroll = function(){
    Limg()
}

//页面加载时调用一次，使图片显示
window.onload = function() {
    var img = document.querySelectorAll("img[data-src]")
    for(var i = 0; i < img.length; i++) {
        img[i].style.opacity = "0"
    }
    Limg()
}

function Limg() {
    var viewHeight = document.documentElement.clientHeight // 可视区域的高度
    var t = document.documentElement.scrollTop || document.body.scrollTop;
    var limg = document.querySelectorAll("img[data-src]")
    // Array.prototype.forEach.call()是一种快速的方法访问forEach，并将空数组的this换成想要遍历的list
    Array.prototype.forEach.call(limg, function(item, index) {
        var rect
        if(item.getAttribute("data-src") === "")
            return
        //getBoundingClientRect用于获取某个元素相对于视窗的位置集合。集合中有top, right, bottom, left等属性。
        rect = item.getBoundingClientRect()
        // 图片一进入可视区，动态加载
        if(rect.bottom >= 0 && rect.top < viewHeight) {
            (function() {
                var img = new Image()
                img.src = item.getAttribute("data-src")
                item.src = img.src
                //给图片添加过渡效果，让图片显示
                var j = 0
                setInterval(function() {
                    j += 0.2
                    if(j <= 1) {
                        item.style.opacity = j
                        return
                    }
                }, 100)
                item.removeAttribute('data-src')
            })()
        }
    })
}