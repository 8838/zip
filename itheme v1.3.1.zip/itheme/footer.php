<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
				<footer class="footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							<div class="footer-wrap">
								<ul class="footer-social thw-share">
									<?php if ($this->options->snsgithub): ?>
										<li><a target="_blank" href="<?php $this->options->snsgithub(); ?>"><i class="zb-github" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									<?php if ($this->options->snswechat): ?>
										<li><a target="_blank" class="openweixin weixin" title="微信"><i class="zb-weixin" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									<?php if ($this->options->snssina): ?>
										<li><a target="_blank" href="<?php $this->options->snssina(); ?>"><i class="zb-weibo" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									<?php if ($this->options->snsqq): ?>
										<li><a target="_blank" href="<?php $this->options->snsqq(); ?>"><i class="zb-qq" aria-hidden="true"></i></a></li>
									<?php endif; ?>
								</ul>
								<div class="thw-heart">Typecho theme  <i class="zb-heart" aria-hidden="true"></i> <a href="https://nichijou.cn">itheme.</a></div>
								<div class="copyright-info"><span>Copyright &copy; 2019 <?php $this->options->title(); ?>. All Rights Reserved.</span></div>
							</div>
                        </div>
                    </div>
                </div>
            </footer>
         </div>
    </div>
	<div class="cd-popup" role="alert">
		<div class="cd-popup-container">
			<p id="qrcode"></p>
			<div class="qrcode-tip">使用微信扫一扫分享</div>
			<a href="#0" class="cd-popup-close img-replace"></a>
		</div>
	</div> 
	<div id="login" class="wnahk">
		<div id="weixinpopup" class="">
			<a class="closeweixin">
				<svg width="14.7" height="14.7" viewBox="0 0 14.7 14.7">
					<path d="M1.7.3L14.4 13a1 1 0 0 1-1.4 1.4L.3 1.7A1 1 0 1 1 1.7.3zm12.7 0a1 1 0 0 1 0 1.4L1.7 14.4A1 1 0 0 1 .3 13L13 .3a1 1 0 0 1 1.4 0z"></path>
				</svg>
			</a>
			<img class="lazy" src="<?php $this->options->snswechat(); ?>" data-original="<?php $this->options->snswechat(); ?>" alt="添加好友" >
			<p>微信扫描添加好友</p>
		</div>
	</div>
<script type='text/javascript' src='<?php $this->options->themeUrl(); ?>js/bootstrap.min.js?ver=1.1'></script>
<script type='text/javascript' src='<?php $this->options->themeUrl(); ?>js/main.js?ver=1.1'></script>
<script src="<?php $this->options->themeUrl('js/lightbox.min.js'); ?>"></script>
<?php $this->footer(); ?>
</body>
</html>