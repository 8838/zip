<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
function themeConfig($form) {
$db = Typecho_Db::get();
$sjdq=$db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:itheme'));
$ysj = $sjdq['value'];
if(isset($_POST['type']))
{ 
if($_POST["type"]=="备份模板数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:ithemebf'))){
$update = $db->update('table.options')->rows(array('value'=>$ysj))->where('name = ?', 'theme:ithemebf');
$updateRows= $db->query($update);
echo '<div class="tongzhi">备份已更新，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}else{
if($ysj){
     $insert = $db->insert('table.options')
    ->rows(array('name' => 'theme:ithemebf','user' => '0','value' => $ysj));
     $insertId = $db->query($insert);
echo '<div class="tongzhi">备份完成，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}
}
        }
if($_POST["type"]=="还原模板数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:ithemebf'))){
$sjdub=$db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:ithemebf'));
$bsj = $sjdub['value'];
$update = $db->update('table.options')->rows(array('value'=>$bsj))->where('name = ?', 'theme:itheme');
$updateRows= $db->query($update);
echo '<div class="tongzhi">检测到模板备份数据，恢复完成，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2000);</script>
<?php
}else{
echo '<div class="tongzhi">没有模板备份数据，恢复不了哦！</div>';
}
}
if($_POST["type"]=="删除备份数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:ithemebf'))){
$delete = $db->delete('table.options')->where ('name = ?', 'theme:ithemebf');
$deletedRows = $db->query($delete);
echo '<div class="tongzhi">删除成功，请等待自动刷新，如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}else{
echo '<div class="tongzhi">不用删了！备份不存在！！！</div>';
}
}
    }
echo '<form class="protected" action="?ithemebf" method="post">
<input type="submit" name="type" class="btn btn-s" value="备份模板数据" />&nbsp;&nbsp;<input type="submit" name="type" class="btn btn-s" value="还原模板数据" />&nbsp;&nbsp;<input type="submit" name="type" class="btn btn-s" value="删除备份数据" /></form>';
$run_style = new Typecho_Widget_Helper_Form_Element_Radio('run_style',
    array('0' => _t('开启'),
        '1' => _t('关闭')),
    '0', _t('图片懒加载'));
$form->addInput($run_style );
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点 LOGO 地址'), _t('在这里填入一个图片 URL 地址, 以在网站标题前加上一个 LOGO'));
    $form->addInput($logoUrl);
    $snsgithub = new Typecho_Widget_Helper_Form_Element_Text('snsgithub', NULL, NULL, _t('Github'), _t('不填写则不显示'));
    $form->addInput($snsgithub);
    $snswechat = new Typecho_Widget_Helper_Form_Element_Text('snswechat', NULL, NULL, _t('Wechat'), _t('不填写则不显示'));
    $form->addInput($snswechat);
    $snssina = new Typecho_Widget_Helper_Form_Element_Text('snssina', NULL, NULL, _t('Sina'), _t('不填写则不显示'));
    $form->addInput($snssina);
    $snsqq = new Typecho_Widget_Helper_Form_Element_Text('snsqq', NULL, NULL, _t('QQ'), _t('不填写则不显示'));
    $form->addInput($snsqq);

}

/**
* 显示下一篇
*
* @access public
* @param string $default 如果没有下一篇,显示的默认文字
* @return void
*/
function theNext($widget, $default = NULL)
{
$db = Typecho_Db::get();
$sql = $db->select()->from('table.contents')
->where('table.contents.created > ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_ASC)
->limit(1);
$content = $db->fetchRow($sql);
 
if ($content) {
$content = $widget->filter($content);
$link = '<a href="' . $content['permalink'] . '" title="' . $content['title'] . '"><span>Next Post <i class="iconfont icon-right"></i></span><h4>' . $content['title'] . '</h4></a>';
echo $link;
} else {
echo '<style>.post-previous {margin-bottom: 0px;}</style>';
echo $default;
}
} 
/**
* 显示上一篇
*
* @access public
* @param string $default 如果没有下一篇,显示的默认文字
* @return void
*/
function thePrev($widget, $default = NULL)
{
$db = Typecho_Db::get();
$sql = $db->select()->from('table.contents')
->where('table.contents.created < ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_DESC)
->limit(1);
$content = $db->fetchRow($sql); 
if ($content) {
$content = $widget->filter($content);
$link = '<a href="' . $content['permalink'] . '" title="' . $content['title'] . '"><span><i class="iconfont icon-left"></i>Previous Post</span><h4>' . $content['title'] . '</h4></a>';
echo $link;
} else {
echo '<style>.post-previous {margin-bottom: 0px;}</style>';
echo $default;
}
}
function themeInit($archive) {
$archive->parameter->pageSize = 5; // 自定义条数
	function Postviews($archive) {
    $db = Typecho_Db::get();
    $cid = $archive->cid;
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $exist = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
    if ($archive->is('single')) {
        $cookie = Typecho_Cookie::get('contents_views');
        $cookie = $cookie ? explode(',', $cookie) : array();
        if (!in_array($cid, $cookie)) {
            $db->query($db->update('table.contents')
                ->rows(array('views' => (int)$exist+1))
                ->where('cid = ?', $cid));
            $exist = (int)$exist+1;
            array_push($cookie, $cid);
            $cookie = implode(',', $cookie);
            Typecho_Cookie::set('contents_views', $cookie);
        }
    }
    return $exist;
}
}
//自定义评论
function threadedComments($comments, $singleCommentOptions) {
    $commentClass = '';
    $commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';
$host = 'https://secure.gravatar.com'; //自定义头像CDN服务器
$url = '/avatar/'; //自定义头像目录,一般保持默认即可
$size = '60'; //自定义头像大小
$rating = Helper::options()->commentsAvatarRating;
$hash = md5(strtolower($comments->mail));
$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=';
?>
<li id="<?php $comments->theId() ?>" class="comment even thread-even depth-1" itemtype="http://schema.org/Comment" itemscope="" itemprop="comment">
			<div id="<?php $comments->theId() ?>">
<div class="comment commentfirst">
					 <div class="author-box">
						<div class="thw-autohr-bio-img">
							<div class="thw-img-border">
								<img class="lazy img-fluid" src="<?php echo $avatar ?>" data-original="<?php echo $avatar ?>">
							</div>
						</div>
					</div>
					<div class="comment-body">
						<div class="meta-data">
							<span class="pull-right"><?php $comments->reply($singleCommentOptions->replyWord);?></span>
                            <span class="comment-author"><?php echo $comments->author; ?></span>
                            <span class="comment-date"><?php $comments->date('M d,Y');?></span>
                        </div>
                        <div class="comment-content">
                            <p><?php $comments->content();?></p>
						</div>   
                    </div>

            <?php if ($comments->children) { ?>
                <ol class="children">
                    <?php $comments->threadedComments($singleCommentOptions);?>
                </ol>
            <?php } ?>
			</div>
    </li>
    <?php
}
function parseContent($obj){
    $options = Typecho_Widget::widget('Widget_Options');
    $obj->content = preg_replace("/<a href=\"([^\"]*)\">/i", "<a href=\"\\1\" rel=\"nofollow\" target=\"_blank\">", $obj->content);
    $obj->content = preg_replace("/<img src=\"([^\"]*)\" alt=\"([^\"]*)\" title=\"([^\"]*)\">/i", "<a href=\"\\1\" data-lightbox=\"img\" data-title=\"\\3\"><img src=\"/usr/themes/itheme/images/loading-img.gif\" data-src=\"\\1\" alt=\"\\2\" title=\"\\3\"></a>", $obj->content);
    echo trim($obj->content);
}
function pContent($obj){
    $options = Typecho_Widget::widget('Widget_Options');
    $obj->content = preg_replace("/<img src=\"([^\"]*)\" alt=\"([^\"]*)\" title=\"([^\"]*)\">/i", "<a href=\"\\1\" data-lightbox=\"img\" data-title=\"\\3\"><img src=\"\\1\" alt=\"\\2\" title=\"\\3\"></a>", $obj->content);
    $obj->content = preg_replace("/<a href=\"([^\"]*)\">/i", "<a href=\"\\1\" rel=\"nofollow\" target=\"_blank\">", $obj->content);
    echo trim($obj->content);
}