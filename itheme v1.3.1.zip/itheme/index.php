<?php
/**
 * itheme是一款单栏主题，以rouvin为原型的一款typecho主题，响应式设计，良好的用户交互。
 * 
 * @package itheme
 * @author Jet
 * @version 1.3.1
 * @link https://nichijou.cn/
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<section class="thw-autohr-bio-wrap">
                <div class="container">
                    <div class="row">
						<div class="col-lg-8 col-md-12">
							<div class="thw-autohr-bio">
								<h2>Hello, 欢迎来到 <strong><?php $this->options->title() ?></strong> </h2>
								<p><?php $this->options->description() ?></p>
								<div class="bio-share">
									<span>关注我</span>
									<ul class="thw-share">
									<?php if ($this->options->snsgithub): ?>
										<li><a target="_blank" href="<?php $this->options->snsgithub(); ?>"><i class="zb-github" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									<?php if ($this->options->snswechat): ?>
										<li><a class="openweixin weixin" title="微信"><i class="zb-weixin" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									<?php if ($this->options->snssina): ?>
										<li><a target="_blank" href="<?php $this->options->snssina(); ?>"><i class="zb-weibo" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									<?php if ($this->options->snsqq): ?>
										<li><a target="_blank" href="<?php $this->options->snsqq(); ?>"><i class="zb-qq" aria-hidden="true"></i></a></li>
									<?php endif; ?>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-12">
                            <div class="thw-autohr-bio-img">
                                <div class="thw-img-border">
																		<img class="lazy img-fluid" src="<?php $this->options->themeUrl(); ?>images/index.jpg" data-original="<?php $this->options->themeUrl(); ?>images/index.jpg" alt="<?php $this->options->title(); ?>" />
									                                </div>
                            </div>
                         </div>
                    </div>
                </div>
            </section>
			<div class="main-container">
                <div class="container">
                    <div class="row">
<?php $counter=0; ?>
<?php while($this->next()): ?>
<?php $counter++; ?>
<?php if($this->is('index') && $this->_currentPage == 1): ?>
<?php if($counter==1) :?>
<div class="col-lg-8 col-md-12 col-sm-12">
<?php else: ?>
<div class="col-lg-4 col-md-12 col-sm-12">
<?php endif; ?>
                            <div class="post-grid">
                                <div class="post-grid-view post-grid-view-lg">
                                    <div class="post-grid-image" onclick="window.open('<?php $this->permalink() ?>','_self')">
<?php if($counter==1) :?>
<?php
preg_match_all("/\<img.*?src\=(\'|\")(.*?)(\'|\")[^>]*>/i", $this->content, $matches);
$imgCount = count($matches[0]);
if($imgCount >= 1){
    $img = $matches[2][0];
echo <<<Html

<img class="lazy img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src={$img}&#38;w=556&#38;h=350&#38;zc=1&#38;q=100">
     
Html;
}else{
echo <<<Html

<img class="lazy img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src=/usr/themes/itheme/images/nopic.png&#38;w=556&#38;h=350&#38;zc=1&#38;q=100">
     
Html;
}
?> 
<?php else: ?>
<?php
preg_match_all("/\<img.*?src\=(\'|\")(.*?)(\'|\")[^>]*>/i", $this->content, $matches);
$imgCount = count($matches[0]);
if($imgCount >= 1){
    $img = $matches[2][0];
echo <<<Html
<a href="{$this->permalink}">
<img class="lazy img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src={$img}&#38;w=265&#38;h=350&#38;zc=1&#38;q=100">     
</a>
Html;
}else{
echo <<<Html
<a href="{$this->permalink}">
<img class="lazy img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src=/usr/themes/itheme/images/nopic.png&#38;w=265&#38;h=350&#38;zc=1&#38;q=100">
</a>
Html;
}
?> 
<?php endif; ?>
<?php else: ?>
<div class="col-lg-4 col-md-12 col-sm-12">
                            <div class="post-grid">
                                <div class="post-grid-view post-grid-view-lg">
                                    <div class="post-grid-image" onclick="window.open('<?php $this->permalink() ?>','_self')">
<?php
preg_match_all("/\<img.*?src\=(\'|\")(.*?)(\'|\")[^>]*>/i", $this->content, $matches);
$imgCount = count($matches[0]);
if($imgCount >= 1){
    $img = $matches[2][0];
echo <<<Html

<img class="img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src={$img}&#38;w=265&#38;h=350&#38;zc=1&#38;q=100">
     
Html;
}else{
echo <<<Html

<img class="img-fluid" aria-label="{$this->title}" href="{$this->permalink}" src="/usr/themes/itheme/timthumb.php?src=/usr/themes/itheme/images/nopic.png&#38;w=265&#38;h=350&#38;zc=1&#38;q=100">
     
Html;
}
?> 
<?php endif; ?>	
								</div>
									<div class="post-content post-content-overlay" onclick="window.open('<?php $this->permalink() ?>','_self')"> 
                                        <div class="post-header"> 
                                            <span class="category-meta"><?php $this->category(','); ?></span>
                                            <h3 class="entry-post-title">
                                              <a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
                                            </h3>
                                        </div>
                                        <div class="post-meta-footer">
                                            <span class="grid-post-date"><?php $this->date('n月 d,Y'); ?></span>
                                            <span class="grid-post-author">
                                                <a class="button like js-action button--primary button--chromeless" data-action="postlike" data-action-value="39">
	<span class="singlelike button-defaultState icon"><i class="zb-heart-o"></i></span><span class="singlelike button-activeState icon"><i class="zb-heart"></i></span><span class="count"><?php $this->commentsNum('0', '1', '%d'); ?></span></a> 谈论 
												<i style="margin: 0 5px;" class="zb-view"></i><?php echo Postviews($this) ?> 浏览
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php endwhile; ?>    
                    </div>
                </div>
            </div>
					<div class="paging">
<?php $this->pageNav('«', '»', 3, '...', array('wrapTag' => 'ul', 'wrapClass' => 'pagination justify-content-center', '' => 'li', 'textTag' => 'span', 'currentClass' => 'active', 'prevClass' => 'prev', 'nextClass' => 'next')) ; ?>
					</div>
<?php $this->need('footer.php'); ?>
