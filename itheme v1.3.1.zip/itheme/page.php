﻿<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div class="thw-title-wrap">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<h2 class="entry-single-title"><?php $this->title() ?></h2>
						</div>
					</div>
				</div>
			</div>
			<div class="main-container">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="page">
																<div class="thw-page-content"><?php if($this->options->run_style){pContent($this);}else{parseContent($this);}?></div>
								<div class="comments-form border-box thw-sept">
<?php $this->need('comments.php'); ?>
                              </div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php $this->need('footer.php'); ?>
