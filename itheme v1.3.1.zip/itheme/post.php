<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<?php Postviews($this); ?>
                  <div class="container">
                        <div class="row">
                              <div class="col-lg-12 col-md-12">
																		
                                    <div id="post-23" class="post-single">
                                        <div class="entry-header single-entry-header"><span class="category-meta"><?php $this->category(','); ?></span><h2 class="entry-title"><?php $this->title() ?></h2><div class="post-meta author-box"><div class="thw-autohr-bio-img"><div class="thw-img-border"><?php echo $this->author->gravatar(60);?></div></div><div class="post-meta-content"><span class="list-post-date">发表于 <?php $this->date('n月 d,Y'); ?></span><span class="post-author">作者：<a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></span><span class="list-post-comment"><?php $this->commentsNum('暂无评论', '1 评论', '%d 评论'); ?></span></div></div></div> 
                                          <div class="entry-content">
										  <?php if($this->options->run_style){pContent($this);}else{parseContent($this);}?>
                                           </div>
                                    </div>
                                    <div class="post-footer clearfix">
                                          		<div class="post-tags"><?php $this->tags('', true, 'none'); ?></div></div>
									
								                            
								
								<div class="comments-form border-box thw-sept">
<?php $this->need('comments.php'); ?>
                              </div>
                        </div>
                  </div>
            </div>
<?php $this->need('footer.php'); ?>
