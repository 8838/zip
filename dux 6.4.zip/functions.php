<?php
// Require theme functions
require get_stylesheet_directory() . '/functions-theme.php';

// Customize your functions

