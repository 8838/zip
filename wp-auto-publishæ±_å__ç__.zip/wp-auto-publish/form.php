<?php 
if ( ! defined( 'ABSPATH' ) ) exit; 

if($_POST['update_draft']){
	if ( ! isset( $_POST['name_of_nonce_field'] ) 
    	|| ! wp_verify_nonce( $_POST['name_of_nonce_field'], 'name_of_my_action' ) 
	) {
   		print 'Sorry, your nonce did not verify.';
	} else {
		update_option('WIND_start_date',sanitize_text_field($_POST['start_date']));
		update_option('WIND_start_time',sanitize_text_field($_POST['start_time']));
		update_option('WIND_interval_time',sanitize_text_field($_POST['interval_to_publish']));
		update_option('WIND_draft_num',sanitize_text_field($_POST['publish_num']));
		update_option('WIND_draf_orderby',sanitize_text_field($_POST['orderby']));
		update_option('WIND_recurrence',sanitize_text_field($_POST['recurrence']));
		update_option('WIND_recurrence_times',sanitize_text_field($_POST['recurrence_to_publish']));
	
		$starTime=get_option('WIND_start_time');
		wp_schedule_event( strtotime(get_option('WIND_start_date')." ".$starTime),'WIND_custom_recurrence','WIND_cron_draft_update_hook' );
	}
}
if($_POST['delete_draft']){
	if ( ! isset( $_POST['name_of_nonce_field'] ) 
    	|| ! wp_verify_nonce( $_POST['name_of_nonce_field'], 'name_of_my_action' ) 
	) {

   		print 'Sorry, your nonce did not verify.';
	} else {
		wp_clear_scheduled_hook( 'WIND_cron_draft_update_hook' );
	}
}
?>

<style type="text/css">
#main{ width:700px; border:1px solid #ccc; background-color:#f9f9f9; padding:10px; margin-top:20px; }
.button-primary{margin-right:20px;}
</style>

<div class="wrap">

	<div id="icon-options-general" class="icon32"><br></div><h2><?php  _e('计划任务', 'wp-auto-publish'); ?></h2>
	
	<div class="card">
	
		<h3><?php  _e('插件设置', 'wp-auto-publish'); ?></h3>
		<hr>
		<div id="draft">
		<form action="" method="post">
			<p><label for="start_publish"><?php  _e('开始时间:', 'wp-auto-publish'); ?></label>
			<input type="date" id="start_date" name="start_date" value="<?php echo get_option('WIND_start_date'); ?>" />
			<?php  _e('时间:', 'wp-auto-publish'); ?><input style="width:100px;" type="time" id="start_time" name="start_time" value="<?php echo get_option('WIND_start_time'); ?>" /> 
			<?php  _e('时间 格式', 'wp-auto-publish'); ?> 11:35</p>
			<p><label for="interval_to_publish"><?php  _e('间隔', 'wp-auto-publish'); ?></label>
			<input style="width:60px;" type="number" min="1" id="interval_to_publish" name="interval_to_publish" value="<?php echo get_option('WIND_interval_time'); ?>" />
			<label for="publish_num"><?php  _e('秒发布一篇,', 'wp-auto-publish'); _e('共发布', 'wp-auto-publish'); ?></label>
			<input style="width:60px;" type="number" min="1" id="publish_num" name="publish_num" value="<?php echo get_option('WIND_draft_num'); ?>" />
			<label for="orderby"><?php  _e('篇,', 'wp-auto-publish');_e('发布顺序', 'wp-auto-publish'); ?></label>
			<select name="orderby">
				<option value="rand" <?php selected( get_option('WIND_draf_orderby'), 'rand' ); ?>><?php  _e('随机', 'wp-auto-publish'); ?></option>
				<option value="ID" <?php selected( get_option('WIND_draf_orderby'), 'ID' ); ?>>ID</option>
			</select>
			</p>
			<p>
			<label for="recurrence"><?php  _e('以上任务每', 'wp-auto-publish'); ?></label><input style="width:60px;" type="number" min="0" id="recurrence_to_publish" name="recurrence_to_publish" value="<?php echo get_option('WIND_recurrence_times'); ?>" />
			<select name="recurrence">
				<option value="daily" <?php selected( get_option('WIND_recurrence'), 'daily' ); ?>><?php  _e('天', 'wp-auto-publish'); ?></option>
				<option value="hourly" <?php selected( get_option('WIND_recurrence'), 'hourly' ); ?>><?php  _e('小时', 'wp-auto-publish'); ?></option>
				<option value="weekly" <?php selected( get_option('WIND_recurrence'), 'weekly' ); ?>><?php  _e('周', 'wp-auto-publish'); ?></option>
			</select> <?php  _e('输入0不重复', 'wp-auto-publish'); ?>
			</P>
			<p>
		<?php 
		submit_button( __('开始执行', 'wp-auto-publish'),'primary','update_draft',''); 
		echo"  " ;
		submit_button(__('取消执行', 'wp-auto-publish'),'secondary','delete_draft','');?>
			</p>
			<?php wp_nonce_field( 'name_of_my_action', 'name_of_nonce_field' ); ?>
		</form>
		<?php if(wp_next_scheduled('WIND_cron_draft_update_hook')):?><p style="color:red"><?php  _e('下次执行时间:', 'wp-auto-publish'); ?>
			<?php echo date('Y-m-d H:i:s',wp_next_scheduled('WIND_cron_draft_update_hook'));?></p>
		<?php else:?>
		<p style="color:gray;"><?php  _e('执行任务已停止!', 'wp-auto-publish'); ?></p>
		<?php endif;?>
		
		</div>
		<hr>
		<div>
			<h3><?php  _e('使用说明', 'wp-auto-publish'); ?></h3>
			<?php  _e('将所有要计划发布的文章存为草稿，并进行如上设定，然后<strong> 更新执行计划</strong> 系统即可按计划运行。', 'wp-auto-publish'); ?>
		</div>
	</div>
<div  class="card">
	<p><?php  _e('插件简介:', 'wp-auto-publish'); ?><a href=" https://www.hostloc.com/forum.php?mod=redirect&goto=findpost&ptid=712537&pid=8739993" target="_blank">wp-auto-publish汉化版</a></p>
	<p><?php  _e('汉化维护:', 'wp-auto-publish'); ?><a href=" https://vpsmm.xyz" target="_blank">小夜图床</a></p>
	<h3>感谢您的捐赠支持！</h3>
	<p>感谢有您捐赠支持本插件的开发，能让我们为您提供更多的助力！ </p>
		<a href="<?php echo plugins_url('ali-pay.jpg',__FILE__) ?>"><img width="200" src="<?php echo plugins_url('ali-pay.jpg',__FILE__) ?>"></a>
		<a href="<?php echo plugins_url('wx-pay.jpg',__FILE__) ?>">	<img width="200" src="<?php echo plugins_url('wx-pay.jpg',__FILE__) ?>"></a>
</div>
</div>
