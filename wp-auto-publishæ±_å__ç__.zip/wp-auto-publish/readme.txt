﻿=== WP-Auto-Publish ===
Contributors:flashcol
Donate link:http://moligu.com/
Tags:  Automatically published, admin, cron, auto post, cron jobs, post missed schedule, scheduled posts, wp-cron, crontrol
Requires at least: 3.1
Tested up to: 4.9
Stable tag: 1.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatic batch timing post. 灵活设定自动批量定时发布文章。

== Description ==
Save all the posts that you plan to publish as a draft and make some settings, then Update and Start.
将所有要计划发布的文章存为草稿，并进行按提示设定，然后 更新执行计划 系统即可按计划运行；
1、可以指定计划任务的开始时间，发布时间间隔，发布数量，
2、可选择按ID升序或随机发布草稿文章。
3、可设置任务的重复间隔（天，小时或周）

== Installation ==
1. WP-Auto-Publish folder to the plugins directory in your WordPress installation.
2. Activate the plugin.
3. Navigate to the "Auto Publish" Menu.
1. 将下载的文件解压缩，然后将`wp-auto-publish`文件夹 上传到 `/wp-content/plugins/`目录
2.在插件后台启用
3.然后在后台管理菜单，点选 ”批量定时发布“菜单即可使用

== Screenshots ==
1. PluginUI 
2. 插件使用界面