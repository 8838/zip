<?php get_header(); ?>
<div class="container am-g am-g-fixed blog-fixed">
	<main role="main" class="am-u-md-8 am-u-sm-12">
		<section>
			<?php get_template_part('loop'); ?>
			<?php get_template_part('pagination'); ?>
		</section>
	</main>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
