<?php get_header(); ?>
<div class="am-g am-g-fixed blog-fixed blog-content" id="page-404">
	<main role="main" class="am-u-md-12 am-u-sm-12">
		<section>
			<article>
				<h1>404</h1>
				<h2>什么东西被吃掉了</h2>
			</article>
		</section>
	</main>
</div>
