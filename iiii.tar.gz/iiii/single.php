<?php get_header(); ?>
<div class="container am-g am-g-fixed blog-fixed blog-content">
	<main role="main" class="am-u-md-8 am-u-sm-12">
	<section>
	<?php if (have_posts()): while (have_posts()) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<h1 class="single-title">
				<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
			</h1>
			<div class="single-meta">
				<span class="single-meta-details single-meta-cat"><span class="am-icon-file-text-o post-meta-icon"></span><?php the_category(', ') ?></span>
				<span class="single-meta-details single-meta-time"><span class="am-icon-clock-o post-meta-icon"></span><?php the_time('Y/m/d'); ?></span>
				<span class="single-meta-details single-meta-com"><span class="am-icon-comment-o post-meta-icon">
					<?php if (comments_open(get_the_ID())){
						comments_popup_link("0","1","%","禁止评论");
					} ?>
				</span></span>
				<span class="single-meta-details"><span class="am-icon-search-plus post-meta-icon"></span></span>
				<span class="single-meta-details"><span class="am-icon-search-minus post-meta-icon"></span></span>
				<?php if( current_user_can( 'manage_options' ) ) {?>
				<span class="single-meta-details"><a href="<?php bloginfo('url'); ?>/wp-admin/post.php?post=<?php echo $post->ID;?>&action=edit" target="_blank"><span class="am-icon-pencil-square-o post-meta-icon"></span></a></span>
				<?php } ?>
			</div>
			<hr>
			<div class="single-content">
				<?php the_content(); ?>
			</div>
			<div class="single-tags">
				<?php the_tags('本文标签：<span class="am-badge am-badge-success">','</span><span class="am-badge am-badge-success">','<span class="am-badge am-badge-success"></span>');?>
			</div>
			<hr>
			<div class="single-copyright-info">
				<?php include "related.php";?>
			</div>
			<hr>
			<?php comments_template(); ?>
		</article>
	<?php endwhile; ?>
	<?php else: ?>
		<article>
			<h1>啥也没有</h1>
		</article>
	<?php endif; ?>
	</section>
	</main>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
