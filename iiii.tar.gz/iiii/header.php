<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php bugxia_head();?>
</head>
<body <?php body_class(); ?>>
	<!-- wrapper -->
	<div class="wrap">
		<div class="am-g">
			<header class="blog-text-center blog-header">
				<div class="am-u-sm-12 am-u-sm-centered">
					<a href="<?php echo home_url(); ?>"><img width="200" src="<?php echo get_template_directory_uri(); ?>/asset/img/notfound.jpg" class="logo_img"></a>
					<h2 class="am-hide-sm-only"><?php bloginfo('description'); ?></h2>
				</div>
			</header>
			<nav class="blog-nav blog-fixed am-u-sm-12 am-u-sm-centered">
				<div class="am-cf am-show-sm-only blog-nav-sm">
					<span class="am-fl">
						<a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/avatar.png" class="logo_img_sm"></a>
					</span>
					<span class="am-fr">
						<button class="am-btn am-btn-sm am-btn-success blog-button" data-am-collapse="{target: '#blog-collapse'}" ><span class="am-icon-bars"></span></button>
					</span>
				</div>
				<div class="am-collapse am-topbar-collapse" id="blog-collapse">
					<?php wp_nav_menu(); ?>
					<ul class="am-nav am-nav-pills am-topbar-nav">
						<li class="am-dropdown" data-am-dropdown="">
						<a class="am-dropdown-toggle" data-am-dropdown-toggle="" href="javascript:;">设置 <span class="am-icon-gear"></span></a>
							<div class="am-dropdown-content settingBox">
								<label class="am-checkbox am-success">
									<input type="checkbox" value="" data-am-ucheck id="ajax_switch"> AJAX加载
								</label>
								<label class="am-checkbox am-success">
									<input type="checkbox" value="" data-am-ucheck id="gravatar_switch"> Gravatar头像
								</label>
							</div>
						</li>
					</ul>
					<?php if( current_user_can( 'manage_options' ) ) {?>
					<ul class="am-nav am-nav-pills am-topbar-nav">
						<li class="am-dropdown" data-am-dropdown="">
						<a class="am-dropdown-toggle" data-am-dropdown-toggle="" href="javascript:;">管理 <span class="am-icon-caret-down"></span></a>
						<ul class="am-dropdown-content">
							<li><a href="<?php bloginfo('url'); ?>/wp-admin/" target="_blank">后台</a></li>
							<li><a href="<?php bloginfo('url'); ?>/wp-login.php?action=logout">退出</a></li>
						</ul>
						</li>
					</ul>
					<?php }?>
					<form class="am-topbar-form am-topbar-right am-form-inline" role="search">
						<div class="am-form-group">
							<input type="text" class="am-form-field am-input-sm" placeholder="回车搜索" name="s">
						</div>
					</form>
				</div>
			</nav>
		</div>
		<hr>
		<!-- /header -->
		