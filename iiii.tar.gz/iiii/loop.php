<?php if (have_posts()): while (have_posts()) : the_post(); ?>
	<article id="post-<?php the_ID(); ?>" class="am-g blog-entry-article">
		<div class="am-u-lg-5 am-u-md-12 am-u-sm-12 blog-entry-img">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
				<img src="<?php echo get_bloginfo('template_directory')."/asset/img/loading_loop.gif";?>" data-original="<?php echo get_bloginfo("url")?>/thumb/400/200/1/85/<?php echo base64_encode(catch_that_image());?>__.jpg" class="lazy am-u-sm-12">
			</a>
		</div>
		<div class="am-u-lg-7 am-u-md-12 am-u-sm-12 blog-entry-text">
			<div class="post-title">
				<h1>
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
				</h1>
			</div>
			<div class="post-excerpt">
				<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150,"..."); ?></p>
			</div>
			<div class="post-meta am-g blog-text-center">
				<span class="am-u-lg-4 am-u-md-4 am-u-sm-6"><span class="am-icon-file-text-o post-meta-icon"></span><?php the_category(', ') ?></span>
				<span class="am-u-lg-4 am-u-md-4 am-u-sm-6"><span class="am-icon-clock-o post-meta-icon"></span><?php the_time('Y/m/d'); ?></span>
				<span class="am-u-lg-4 am-u-md-4 am-hide-sm-only"><span class="am-icon-comment-o post-meta-icon"></span>
					<?php if (comments_open(get_the_ID())){
						comments_popup_link("0","1","%","禁止评论");
					} ?>
				</span>
			</div>
		</div>
	</article>
<?php endwhile; ?>
<?php else: ?>
	<article>
		<h2>啥都没有</h2>
	</article>
<?php endif; ?>
