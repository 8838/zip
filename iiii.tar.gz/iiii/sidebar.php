﻿<aside class="sidebar am-u-md-4 am-u-sm-12 blog-sidebar" role="complementary">
	<div class="blog-sidebar-widget blog-sidebar-widget-center blog-bor">
		<h2 class="blog-text-center blog-sidebar-title"><span>About ME</span></h2>
		<span class="am-icon-btn aboutme">
			<img src="<?php echo get_template_directory_uri(); ?>/asset/img/logo_b.png" alt="about me" class="">
		</span>
		<p>Hello</p>
		<p>探索未知，记录点滴！</p>
	</div>
	<div id="recent-comments-2" class="widget_recent_comments blog-sidebar-widget blog-bor">
		<h2 class="blog-text-center blog-sidebar-title"><span>近期评论</span></h2>
		<ul class="siderbar-comment">
			<?php sidebar_newcomment();?>
		</ul>
	</div>
	<div class="sidebar-widget">
		<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-widget')) ?>
	</div>
</aside>