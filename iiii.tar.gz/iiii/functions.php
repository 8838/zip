<?php
//加载评论
function fa_ajax_comment_scripts(){
	wp_enqueue_script( 'ajax-comment', get_template_directory_uri() . '/asset/js/ajax-comment.js', array( 'jquery' ),false , true );
	wp_localize_script( 'ajax-comment', 'ajaxcomment', array(
		'ajax_url'   => admin_url('admin-ajax.php'),
		'order' => get_option('comment_order'),
		'formpostion' => 'bottom',
	) );
}

function fa_ajax_comment_err($a) {
	header('HTTP/1.0 500 Internal Server Error');
	header('Content-Type: text/plain;charset=UTF-8');
	echo $a;
	exit;
}

function fa_ajax_comment_callback(){
	$comment = wp_handle_comment_submission( wp_unslash( $_POST ) );
	if ( is_wp_error( $comment ) ) {
		$data = $comment->get_error_data();
		if ( ! empty( $data ) ) {
			fa_ajax_comment_err($comment->get_error_message());
		} else {
			exit;
		}
	}
	$user = wp_get_current_user();
	do_action('set_comment_cookies', $comment, $user);
	$GLOBALS['comment'] = $comment;
	?>
	<li <?php comment_class(); ?>>
		<article class="am-comment" id="div-comment-<?php comment_ID() ?>">
			<a href="javascript:;">
				<img alt="" src="<?php echo get_template_directory_uri(); ?>/asset/img/avatar.png" class="avatar avatar-48 photo am-comment-avatar" height="48" width="48">
			</a>
			<div class="am-comment-main">
				<header class="am-comment-hd">
					<!--<h3 class="am-comment-title">评论标题</h3>-->
					<div class="am-comment-meta">
						<?php if($comment->comment_author_email == get_bloginfo ('admin_email') or $comment->user_id == '1'){ ?>
						<span class="am-comment-author comment-admin"><?php echo get_user_meta( $comment->user_id,'nickname',true);?><span class="am-icon-check-circle"></span></span>
						<?php }else{ ?>
						<span class="am-comment-author"><?php echo get_comment_author_link();?></span>
						<?php } ?>
						评论于 <time><?php echo get_comment_date(); ?></time>
					</div>
				</header>
				<div class="am-comment-bd">
				<?php comment_text(); ?>
				<?php if ($comment->comment_approved == '0') : ?>
					<em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.') ?></em>
				<?php endif; ?>
				</div>
			</div>
		</article>
	</li>
	<?php die();
}
add_action( 'wp_enqueue_scripts', 'fa_ajax_comment_scripts' );
add_action('wp_ajax_nopriv_ajax_comment', 'fa_ajax_comment_callback');
add_action('wp_ajax_ajax_comment', 'fa_ajax_comment_callback');

//百度收录提交
function push_to_baidu($ID) {
	$permalink = get_permalink($ID);
	$api = 'http://data.zz.baidu.com/urls?site=bugxia.com&token=代码替换';
	$ch = curl_init();
	$options =  array(
		CURLOPT_URL => $api,
		CURLOPT_POST => true,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_POSTFIELDS => $permalink,
		CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
	);
	curl_setopt_array($ch, $options);
	$result = curl_exec($ch);
	//写推送日志到主题目录
	file_put_contents(dirname(__FILE__)."/Baidu_Push_Log.txt",$result."\n",FILE_APPEND);
}
//add_action('publish_post', 'push_to_baidu');

//上传文件改名
function rename_upload_img($file) {
	$time=date("YmdHis");
	//以md5或日期改名
	//$file['name'] = md5($file['name']).".".pathinfo($file['name'] , PATHINFO_EXTENSION);
	$file['name'] = $time."".mt_rand(100,999).".".pathinfo($file['name'] , PATHINFO_EXTENSION);
	return $file;
}
add_filter('wp_handle_upload_prefilter', 'rename_upload_img');

//获取日志第一张图片
function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	$first_img_DB = get_post_meta($post->ID, 'first_img', true);
	if(!empty($first_img_DB)){
		$first_img = $first_img_DB;
	}else{
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
		$first_img = $matches [1] [0];
		if(empty($first_img)){
		  $first_img = get_template_directory_uri()."/asset/img/notfound.jpg";
		}
		//add_post_meta($post->ID, "first_img", $first_img, TRUE);
	}
	return $first_img;
}

// 评论添加@
function comment_add_at( $comment_text, $comment = '') {
	if( $comment->comment_parent > 0) {
		$comment_text = '@'.get_comment_author( $comment->comment_parent )."  ".$comment_text;
	}
	return $comment_text;
}
add_filter( 'comment_text' , 'comment_add_at', 20, 2);
add_filter( 'add_image_size', create_function( '', 'return 1;' ) );

//修改评论表情调用路径
function custom_smilies_src($src, $img)
{
    return get_bloginfo('template_directory') . '/asset/img/smilies/' . $img;
}
add_filter('smilies_src','custom_smilies_src',1,10);

if (!isset($wpsmiliestrans)) {
	$wpsmiliestrans = array(
		":二哈:" => "erha.png",
		":嘻嘻:" => "xixi.png",
		":笑哭:" => "xiaoku.png",
		":嘴锤:" => "punch.png",
		":萌:" => "meng.png",
		":咧嘴:" => "liezui.png",
		":困:" => "kun.png",
		":哭:" => "ku.png",
		":抠鼻:" => "koubi.png",
		":可爱:" => "keai.png",
		":惊讶:" => "jingya.png",
		":汗:" => "han.png",
		":害羞:" => "haixiu.png",
		":doge:" => "doge.png",
		":大笑:" => "daxiao.png"
	);
}

//替换换行符、制表符
function myTrim($str){
	$search = array("　","\n","\r","\t");
	$replace = array("","","","");
	return str_replace($search, $replace, $str);
}

//自定义头部信息
function bugxia_head() {
	if ( is_home() ) : ?><title><?php bloginfo('name'); ?></title>
	<?php elseif ( is_search() ) : ?><title><?php echo $_GET['s']; ?>的搜索结果 | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_single() ) : ?><title><?php echo trim(wp_title('', false)); ?> | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_page() ) : ?><title><?php echo trim(wp_title('', false)); ?> | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_category() ): ?><title><?php single_cat_title(); ?> | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_year() ) : ?><title><?php the_time('Y年'); ?>发布的内容 | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_month() ) : ?><title><?php the_time('Y年n月'); ?>发布的内容 | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_day() ) : ?><title><?php the_time('Y年n月j日'); ?>发布的内容 | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_tag() ) : ?><title><?php  single_tag_title("", true); ?> | <?php bloginfo('name'); ?></title>
	<?php elseif ( is_author() ):?><title><?php wp_title(''); ?>发布的所有内容 | <?php bloginfo('name'); ?></title>
	<?php endif;?>
	<?php 
		$keywords = 'iiii.im,vps,服务器,linux教程,php教程';
		$description = get_bloginfo('description');
	?>
	<?php if(is_single()):?>
	<?php 
		$keywords = strip_tags( get_the_tag_list( '',',','') );
		if(!$keywords){
			$keywords="iiii.im,vps,服务器,linux教程,php教程";
		}
		$post = get_post();
		$description = myTrim(mb_substr(strip_tags(apply_filters('the_content',$post->post_content)),0,220,"utf-8"));
	?>
	<?php elseif (is_category() ): ?>
	<?php 
		$keywords =  single_cat_title( '', false ) ;
		$cate_desc = category_description();
		$description = $cate_desc ? strip_tags( category_description() ) . ',' . $description : $description;
	?>
	<?php elseif (is_tag() ): ?>
	<?php 
		$keywords = single_tag_title( '', false ) ;
	?>
	<?php elseif (is_page() ): ?>
	<?php 
		$p_title = trim ( wp_title('', false) );
		$keywords = "{$p_title}";
	?>
	<?php endif; ?>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<meta name="keywords" content="<?php echo $keywords; ?>" />
	<meta name="description" content="<?php echo trim($description); ?>" />
	<link href="<?php echo get_template_directory_uri(); ?>/asset/img/fav.ico" rel="shortcut icon">
	<link href="https://cdn.bootcss.com/amazeui/2.7.2/css/amazeui.flat.min.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/asset/css/amazeui.hack.css?v=<?php echo rand();?>">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css?v=<?php echo rand();?>">
	<?php 
	wp_head();
	//判断是否使用了Pure-Highlightjs插件
	include_once(ABSPATH.'wp-admin/includes/plugin.php' );
	if(is_plugin_active('Pure-Highlightjs-1.0/pure-highlightjs.php' )){
		echo '<script>var highlight_pluginUrl = "'.plugins_url().'/Pure-Highlightjs-1.0/highlight/highlight.pack.js";</script>';
	}else{
		echo '<script>var highlight_pluginUrl = false;</script>';
	}
}

//侧边栏评论
function sidebar_newcomment($limit=6,$outer=1 ){
	global $wpdb;
	$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved,comment_author_email, comment_type,comment_author_url, SUBSTRING(comment_content,1,40) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE user_id!='".$outer."' AND comment_approved = '1' AND comment_type = '' AND post_password = '' ORDER BY comment_date_gmt DESC LIMIT $limit";
	$comments = $wpdb->get_results($sql);
	foreach ( $comments as $comment ) {
		$output .= '
		<li class="am-g sidebar_newcomment_line">
			<span class="am-u-sm-2 sidebar_newcomment_avatar blog-text-center"><img class="gravtar" src="'.get_random_avatar().'" gravatar-url="'.get_cache_avatar($comment->comment_author_email,array('size'=>'32')).'"></span><span class="am-u-sm-10 sidebar_newcomment_content am-text-top">'.strip_tags($comment->comment_author).' 在<a href="'.get_permalink($comment->ID).'#comment-'.$comment->comment_ID.'" title="'.$comment->post_title.'上的评论">《'.$comment->post_title.'》</a>说：<span class="sidebar_newcomment_com_excerpt">'.strip_tags($comment->com_excerpt).'</span></span>
		</li>';
	}
	echo $output;
}

//随机头像
function get_random_avatar(){
	return get_bloginfo('template_directory').'/asset/img/ravatar/'.rand(1,15).'.png';
}

//gravatar缓存，未启用
function get_cache_avatar($email,$args,$enable=true){
	if($enable==true){
		//$origin = httpsGet(get_avatar_url($email,$args));
		$origin = httpsGet("https://cdn.v2ex.com/gravatar/".md5($email)."?s=32&d=mm&r=g");
		$local = dirname(__FILE__)."/asset/img/avatarCache/".md5($email).".jpg";
		$t = 10*24*60*60; 
		if(file_exists($local) and  (time() - filemtime($local)) < $t){
			return get_bloginfo('template_directory')."/asset/img/avatarCache/".md5($email).".jpg?tag=local";
		}else{
			$save = file_put_contents($local,$origin);
			if($save == 0){
				return get_bloginfo('template_directory').'/asset/img/avatar.png?t=cacheFail';
			}else{
				return get_bloginfo('template_directory')."/asset/img/avatarCache/".md5($email).".jpg?tag=cacheSuccess";
			}
		}
	}else{
		return "https://cdn.v2ex.com/gravatar/".md5($email)."?s=32&d=mm&r=g";
		//return get_avatar_url($email,$args);
	}
}

//httpsGet
function httpsGet($url){
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_HEADER,0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_SSLVERSION , CURL_SSLVERSION_DEFAULT);
	$res = curl_exec($ch);
	curl_close($ch);
	return $res;
}

//LazyLoad
function lazyload($content) {
	if(!is_feed()) {
		$lazyIMG = get_bloginfo('template_directory')."/asset/img/loading_single.gif";
		if ($is_strict == true) {
			$regexp = "/<img([^<>]*)src=['\"]([^<>'\"]*)\.(bmp|gif|jpeg|jpg|png)([^<>'\"]*)['\"]([^<>]*)>/i";
			$replace = '<img$1src="'.$lazyIMG.'" data-original="$2.$3$4"$5><noscript>'.$matches[0].'</noscript>';
		}else{
			$regexp = "/<img([^<>]*)src=['\"]([^<>'\"]*)['\"]([^<>]*)>/i";
			$replace = '<img$1src="'.$lazyIMG.'" data-original="$2"$3><noscript>'.$matches[0].'</noscript>';
		}
		$content_tmp=preg_replace($regexp,$replace,$content);
		$newcontent = preg_replace('/class\s*=\s*"/i', 'class="lazy ', $content_tmp);
	}
	return $newcontent;
}
add_filter ('the_content', 'lazyload');

//禁用emojis
function disable_emojis() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );    
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );  
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'disable_emojis' );

//后台编辑器表情
function fa_get_wpsmiliestrans(){
    global $wpsmiliestrans;
    $wpsmilies = array_unique($wpsmiliestrans);
    foreach($wpsmilies as $alt => $src_path){
        $output .= '<a class="add-smily" data-smilies="'.$alt.'"><img class="wp-smiley" src="'.get_bloginfo('template_directory').'/asset/img/smilies/'.$src_path.'" /></a>';
    }
    return $output;
}
function fa_smilies_custom_button($context) {
    $context .= '<style>.smilies-wrap{background:#fff;border: 1px solid #ccc;box-shadow: 2px 2px 3px rgba(0, 0, 0, 0.24);padding: 15px;position: absolute;top: 55px;width: 280px;display:none}.smilies-wrap img{cursor:pointer;margin-bottom:5px} .is-active.smilies-wrap{display:block}</style><a id="REPLACE-media-button" style="position:relative" class="button REPLACE-smilies add_smilies" title="添加表情" data-editor="content" href="javascript:;">添加表情</a><div class="smilies-wrap">'. fa_get_wpsmiliestrans() .'</div><script>jQuery(document).ready(function(){jQuery(document).on("click", ".REPLACE-smilies",function() { if(jQuery(".smilies-wrap").hasClass("is-active")){jQuery(".smilies-wrap").removeClass("is-active");}else{jQuery(".smilies-wrap").addClass("is-active");}});jQuery(document).on("click", ".add-smily",function() { send_to_editor(" " + jQuery(this).data("smilies") + " ");jQuery(".smilies-wrap").removeClass("is-active");return false;});});</script>';
    return $context;
}
add_action('media_buttons_context', 'fa_smilies_custom_button');

//删除原表情中的宽高
function reset_smilies_style( $content ) {
	return str_replace( 'class="wp-smiley" style="height: 1em; max-height: 1em;"', 'class="wp-smiley"', $content );
}
add_filter( 'the_content', 'reset_smilies_style', 99 );
add_filter( 'the_excerpt', 'reset_smilies_style', 99 );
add_filter( 'comment_text', 'reset_smilies_style', 99 );

//侧边栏
if (function_exists('register_sidebar'))
{
    register_sidebar(array(
        'name' => '侧边栏小工具栏',
        'description' => '侧边栏小工具栏',
        'id' => 'sidebar-widget',
        'before_widget' => '<div id="%1$s" class="%2$s blog-sidebar-widget blog-bor">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="blog-text-center blog-sidebar-title"><span>',
        'after_title' => '</h2>'
    ));
}

function pagenavi( $p = 4 ) {
	if ( is_singular() ) return;
	global $wp_query, $paged;
	$max_page = $wp_query->max_num_pages;
	if ( $max_page == 1 ) return;
	echo '<ul class="am-pagination">';
	echo '<li><a href="'.get_option("siteurl").'" title="首页" class="layui-laypage-prev">首页</a></li>';
	if ( empty( $paged ) ) $paged = 1;
	if ( $paged > 1 ) p_link( $paged - 1, '&laquo; 上一页', '&laquo; 上一页' );
	if ( $paged > $p + 2 ) echo '<span class="layui-laypage-spr">…</span>';
	for( $i = $paged - $p; $i <= $paged + $p; $i++ ) {
		if ( $i > 0 && $i <= $max_page ) $i == $paged ? print '<li class="am-active"><a href="#">'.$i.'</a></li>' : p_link( $i );
	}
	if ( $paged < $max_page - $p - 1 ) echo '<span class="layui-laypage-spr">…</span>';
	if ( $paged < $max_page ) p_link( $paged + 1,'下一页 &raquo;', '下一页 &raquo;' );
	echo '<li><a href="'.get_pagenum_link($max_page).'" title="尾页">尾页</a></li>';
	echo '</ul>';
	wp_reset_query();
}

function p_link( $i, $title = '', $linktype = '' ) {
		if ( $title == '' ) $title = "第 {$i} 页";
		if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; }
		echo "<li><a href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$linktext}</a></li>";
}

//评论内容检查
function check_comment_post( $incoming_comment ) {
	$email = $incoming_comment['comment_author_email'];
	if($email == get_bloginfo ('admin_email') and !is_user_logged_in()){
		fa_ajax_comment_err("请勿使用本站管理员邮箱");
	}
	$pattern = '/[一-龥]/u';  
	$http = '/[href="|rel="nofollow"|http\/\/|<\/a>]/u'; 

	if(!preg_match($pattern, $incoming_comment['comment_content'])) {
		fa_ajax_comment_err("Please enter some Chinese words to show that you are not a robot.");
	}
	
	/*if(preg_match($http, $incoming_comment['comment_content'])) {
		fa_ajax_comment_err("当前设置不允许提交超链接");
	}*/
	
	return( $incoming_comment );  
}
add_filter('preprocess_comment', 'check_comment_post');

//评论方糖通知站长
function sendFTQQ($comment_ID,$comment_approved){
	if( 1 === $comment_approved){
		$comment = get_comment($comment_ID);
		if($comment->comment_author_email != get_bloginfo ('admin_email')){
			$author=$comment->comment_author;
			$content=$comment->comment_content;
			$comment = $author.'：'.$content.'';
			$SCKEY = "SCU101850T256b66e342895bd26c17106b45e1053e5ee85c6ad802b";
			$url = 'https://sc.ftqq.com/'.$SCKEY.'.send?desp='.urlencode($comment).'&text='.urlencode("博客新评论通知");
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
			curl_setopt($ch, CURLOPT_SSLVERSION , CURL_SSLVERSION_DEFAULT);
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);        
			curl_setopt($ch, CURLOPT_TIMEOUT, 1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
			$result = curl_exec($ch);
			curl_close($ch);
			return;
		}
	}
}
//add_action( 'comment_post', 'sendFTQQ', 10, 2 );

//邮件通知
function comment_mail_notify($comment_id) {
	$comment = get_comment($comment_id);
	$content=$comment->comment_content;
	$match_count=preg_match_all('/<a href="#comment-([0-9]+)?" rel="nofollow">/si',$content,$matchs);
	if($match_count>0){
		foreach($matchs[1] as $parent_id){
			send_comment_email($parent_id,$comment);
		}
	}elseif($comment->comment_parent!='0'){
		$parent_id=$comment->comment_parent;
		send_comment_email($parent_id,$comment);
	}
	else{
		return;	
	}
}
add_action('comment_post', 'comment_mail_notify');

//邮件通知
function send_comment_email($parent_id,$comment){
     $admin_email = get_bloginfo ('admin_email');
     $parent_comment=get_comment($parent_id);
     $author_email=$comment->comment_author_email;
     $to = trim($parent_comment->comment_author_email);
     $spam_confirmed = $comment->comment_approved;
     if ($spam_confirmed != 'spam' and $to != $admin_email) {
         $wp_email = 'admin@bugxia.com';
         $subject = '您在 [' . get_option("blogname") . '] 的留言有了回复';
         $message = '
		 <div style="background-color:#f9f9f9;border:1px solid #f9f9f9;color:#111;padding:0 15px;border-radius:5px;box-shadow: 2px 2px 6px #ddd;">
			<p>'. trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
			<div style="text-indent: 1em;">
				<p>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言：</p>
				<p style="font-weight: bold;color: #ff6c00;">'. trim(get_comment($parent_id)->comment_content) . '</p>
				<p><span>「'. trim($comment->comment_author) . '」</span>给您的回复：</p>
				<p style="font-weight: bold;color: #8ebd04;">'. trim($comment->comment_content) . '</p>
				<div style="font-size:12px;color:#bbb;border-top: 1px solid #ececec;">
					<p>您可以点击 <a href="'.htmlspecialchars(get_comment_link($parent_id,array("type" => "all"))).'">查看回复的完整內容</a></p>
					<p>欢迎再度访问 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
					<p>(此邮件有系统自动发出, 请勿回复.)</p>
				</div>
			</div>
		</div>';
         $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
         $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
         wp_mail( $to, $subject, $message, $headers );
     }
 }
 
//评论回调函数
function bugxia_comments($comment, $args, $depth)
{
	$GLOBALS['comment'] = $comment;
	extract($args, EXTR_SKIP);
	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'div';
		$add_below = 'div-comment';
	}
?>
    <li <?php comment_class(); ?>>
		<article class="am-comment" id="div-comment-<?php comment_ID() ?>">
			<a href="javascript:;">
			
				<img class="am-comment-avatar gravtar" width="48" height="48" src="<?php echo get_random_avatar();?>" gravatar-url="<?php echo get_cache_avatar($comment->comment_author_email,array('size'=>'48'));?>">
			</a>
			<div class="am-comment-main">
				<header class="am-comment-hd">
					<div class="am-comment-meta">
						<?php if($comment->comment_author_email == get_bloginfo ('admin_email') or $comment->user_id == '1'){ ?>
						<span class="am-comment-author comment-admin"><?php echo get_user_meta( $comment->user_id,'nickname',true);?><span class="am-icon-check-circle"></span></span>
						<?php }else{ ?>
						<span class="am-comment-author"><?php echo get_comment_author_link();?></span>
						<?php } ?>
						评论于 <time><?php printf( __('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></time>
					</div>
				</header>
				<div class="am-comment-bd">
				<?php comment_text(); ?>
				<?php if ($comment->comment_approved == '0') : ?>
					<em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.') ?></em>
				<?php endif; ?>
				</div>
				<footer class="am-comment-footer">
					<div class="am-comment-actions">
						<?php comment_reply_link(array_merge( $args, array('add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'], 'before' => '<i class="am-icon-reply">', 'after' => '</i>'))) ?>
					</div>
				</footer>
			</div>
		</article>
    </li>

<?php }

?>
