var ajax_switch_cookie;
var gravatar_switch_cookie
var contentSize;

function init_just_load(){
	
	//导航栏顶部固定
	var browserWidth = $(window).width();
	if (browserWidth > 1024) {
		$(".blog-nav").attr("data-am-sticky",true);
	}
	//导航栏变更class
	$("#blog-collapse ul").first().addClass("am-nav am-nav-pills am-topbar-nav");
	$(".menu-item-has-children").addClass("am-dropdown");
	$(".menu-item-has-children").attr("data-am-dropdown","");
	$(".menu-item-has-children a").first().addClass("am-dropdown-toggle");
	$(".menu-item-has-children a").first().attr("data-am-dropdown-toggle","");
	$(".menu-item-has-children a").first().attr("href","javascript:;");
	$(".sub-menu").addClass("am-dropdown-content");
	//gotop位置修改
	var mainPosition = $('main').offset().left;
	var mainWidth = $('main').width();
	var gotopPosition = $(window).width() - mainPosition -mainWidth;
	if(browserWidth>768){
		$(".am-gotop").css("right",gotopPosition-60);
	}
	//开关控制
	ajax_switch_cookie = getCookie("ajax_switch");
	gravatar_switch_cookie = getCookie("gravatar_switch");
	//ajax
	if(ajax_switch_cookie=="yes"){
		$("#ajax_switch").attr("checked",true);
	}else{
		$("#ajax_switch").attr("checked",false);
	}
	//gravatar
	if(gravatar_switch_cookie==null){
		setCookie("gravatar_switch","no");
		$("#gravatar_switch").attr("checked",false);
	}else{
		if(gravatar_switch_cookie=="yes"){
			$("#gravatar_switch").attr("checked",true);
			changeGravatar();
		}else{
			$("#gravatar_switch").attr("checked",false);
		}
	}
	//设置开关
	$("#ajax_switch").change(function() {
		if($(this).is(':checked')==true){
			setCookie("ajax_switch","yes");
			console.log("AJAX 开启"); 
		}else{
			setCookie("ajax_switch","no");
			console.log("AJAX 关闭");
		}
		window.location.reload();
	});

	$("#gravatar_switch").change(function() {
		if($(this).is(':checked')==true){
			setCookie("gravatar_switch","yes");
			console.log("Gravatar 开启"); 
		}else{
			setCookie("gravatar_switch","no");
			console.log("Gravatar 关闭"); 
		}
		window.location.reload();
	});
	//cookieTest
	cookieTest();
}

function init(){
	//字体大小
	contentSize = getCookie("contentSize");
	if(contentSize != null && parseInt(contentSize) > 11 && parseInt(contentSize) < 24){
		$(".single-content").css("font-size",contentSize+"px");
	}
	//插入表情至评论框
	$('#smileBox').on('click',".smileface",function() {
		var faceName = $(this).find("img").attr("title");
		faceName = " :"+faceName+": ";
		var str = $('#comment').val();
		$('#comment').val(str+faceName);
	});
	//字体放大
	$('.single-meta .am-icon-search-plus').click(function() {
		var originSize = parseInt($(".single-content").css("font-size"));
		if(originSize > 24){ return false; }
		var newSize = originSize + 1;
		setCookie("contentSize",newSize);
		$(".single-content").css("font-size",newSize+"px")
	});
	//字体缩小
	$('.single-meta .am-icon-search-minus').click(function() {
		var originSize = parseInt($(".single-content").css("font-size"));
		if(originSize < 12){ return false; }
		var newSize = originSize - 1;
		setCookie("contentSize",newSize);
		$(".single-content").css("font-size",newSize+"px")
	});
	//显示表情
	$('#smileBox').on('click',".insertSmileFace",function() {
		$(".smileBox").show();
		$("#smileBox").html($(".smileBox"));
		$(".smileBox").addClass("am-animation-shake");
	});
	//LazyLoad
	$("img.lazy").lazyload({
		effect: "fadeIn",
	});	
	 
	//判断gravatar是否需要加载
	if(getCookie("gravatar_switch")=="yes"){
		changeGravatar();
	}

	//复制code
	$("pre").hover(
		function(){
			$(".float_copy").remove();
			var e = $(this);
			e.append('<div class="float_copy"><span class="am-icon-clipboard"></span></div>');
			var f = $(".float_copy");
			var lines = Math.round(e.height()/parseFloat(e.css('line-height')));
			if(lines < 2){
				var left = e.position().left + e.width() - f.width() - 5;
				var top = e.position().top + e.height()/2;
			}else{
				var left = e.position().left + e.width() - f.width() - 5;
				var top = e.position().top + 15;
			}
			$(".float_copy").attr("style","left:"+left+"px;top:"+top+"px");
			$(".float_copy").click(function() {
				e.children("code").selectText();
			});
			$(".float_copy").show();
		},function(){
			$(".float_copy").stop().hide();
			$(".float_copy").unbind();
			$(".float_copy").remove();
		}
	)
	//判断是否需要加载代码高亮JS
	if(highlight_pluginUrl != false){
		loadscript(highlight_pluginUrl,function () {
			hljs.initHighlighting();
		});
	}
	
	//判断百度统计
	if (typeof _hmt == "undefined") {
		$(".baidu_script").html("统计失败");
		console.log("您的浏览器可能开启了插件，屏蔽了本站的统计信息")
	}
	
}

init();
init_just_load();

/*
$('body').imagesLoaded()
  .progress( function( instance, image ) {
    console.log('每张图片加载完');
    var result = image.isLoaded ? 'loaded' : 'broken';
    console.log( '加载结果 ' + result + ' 图片地址 ' + image.img.src );
  });
*/

//导航栏点击返回
var $dropdown = $('.am-dropdown'),
data = $dropdown.data('amui.dropdown');
$('.am-dropdown').on('click','.am-dropdown-content a',function(e) {
	$('.am-dropdown').dropdown('close');
});

$('.am-nav').on('click','.menu-item a',function(e) {
	$('.am-dropdown').dropdown('close');
});

//selectText
jQuery.fn.selectText = function(){
    
    this.find('input').each(function() {
        if($(this).prev().length == 0 || !$(this).prev().hasClass('p_copy')) { 
            $('<p class="p_copy" style="position: absolute; z-index: -1;"></p>').insertBefore($(this));
        }
        $(this).prev().html($(this).val());
    });
    
    var doc = document;
    var element = this[0];
    if (doc.body.createTextRange) {
        var range = document.body.createTextRange();
        range.moveToElementText(element);
        range.select();
    } else if (window.getSelection) {
        var selection = window.getSelection();        
        var range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
    }
};

//changeGravatar
function changeGravatar(){
	$(".gravtar").each(function(){
		$(this).attr("src",$(this).attr("gravatar-url"));
		$(this).attr("data-original","");
	})
}

//cookieTest
function cookieTest() {
	setCookie('cookieTest', '1');
	var cookieTest = getCookie('cookieTest');
	if ('1' != cookieTest) {
		alert("您的浏览器不支持cookie，或您屏蔽了本站cookie\n请开启浏览器cookie功能以正常浏览本站！");
		$("html").hide();
	} else {
		return "Cookie Test is PASS";
	}
}

//setCookie
function setCookie(name, value) {
	var exp = new Date();
	exp.setTime(exp.getTime() + 10 * 24 * 60 * 60 * 1000);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + ";path=/";
}

//getCookie
function getCookie(name) {
	var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
	if (arr = document.cookie.match(reg)) return unescape(arr[2]);
	else return null;
}

//gotop
function gotop(to) {
	to = isNaN(to) ? $('#' + to)["offset"]()["top"] : to;
	$("body,html")["animate"]({
		scrollTop: to
	}, 200);
	return false
};

//loadJS
function loadscript(url, callback){
    var script = document.createElement ("script")
    script.type = "text/javascript";
    if (script.readyState){
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" || script.readyState == "complete"){
                script.onreadystatechange = null;
                callback();
            }
        };
    } else {
        script.onload = function(){
            callback();
        };
    }
    script.src = url;
    document.getElementsByTagName("head")[0].appendChild(script);
}