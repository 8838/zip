//href
function isNoAjaxHref(href){
	if(href=="" || href == undefined){
		return true;
	}
	var noAjaxHref = new String('javascript,wp-admin,#top,wp-login,tyadmin').split(',');
	for (var i=0;i<noAjaxHref.length;i++){
		if(href.indexOf(noAjaxHref[i]) != -1){
			return false
		}
	}
	return true
}

//CLASS
function isNoAjaxClass(className){
	if(className=="" || className == undefined){
		return true;
	}
	var noAjaxClass = new String('comment-reply-link,am-dropdown-toggle,cancel-comment-reply-link,smileface').split(',');
	for (var i=0;i<noAjaxClass.length;i++){
		if(className.indexOf(noAjaxClass[i]) != -1){
			return false
		}
	}
	return true
}

//ID
function isNoAjaxID(id){
	if(id=="" || id == undefined){
		return true;
	}
	var noAjaxID = new String('cancel-comment-reply-link').split(',');
	for (var i=0;i<noAjaxID.length;i++){
		if(id.indexOf(noAjaxID[i]) != -1){
			return false
		}
	}
	return true
}

function setState(pageUrl,pageTitle){
	var stateobj = ({
		url:pageUrl,
		title:pageTitle
	});
	window.history.pushState(stateobj,null,pageUrl);
}

$("body").on("click","a",
function() {
	var currentUrl = window.location.href;
	if (isNoAjaxHref($(this).attr("href")) == true && isNoAjaxClass($(this).attr("class")) == true && isNoAjaxID($(this).attr("id")) == true) {
		setState($(this).attr("href"),$("title").text())
		$.ajax({
			url: $(this).attr("href"),
			beforeSend: function() {
				$('main').append('<div class="ajax_loading_body"><div class="spinner"><div class="double-bounce1"></div><div class="double-bounce2"></div></div></div>');
			},
			timeout: 5000,
			error: function() {
				$('.ajax_loading_body').remove();
				location["href"] = url;
			},
			success: function(data) {
				var targetUrl = window.location.pathname;
				//var targetUrl = window.location.href;
				console.log(targetUrl);
				document.title = $(data).filter("title").text();
				$("main").replaceWith($(data).find("main"));
				$('main').append('<div class="ajax_loading_body"><div class="spinner"><div class="double-bounce1"></div><div class="double-bounce2"></div></div></div>')
				gotop(0);
				if (typeof _hmt != "undefined") {
					_hmt.push(['_trackPageview', targetUrl]);
				}
			},
			complete: function() {
				$('.ajax_loading_body').remove();
				init();
			}
		});
		return false
	}
});
$(window).bind("popstate",function(){
	var targetUrl = window.location.pathname;
	var currentUrl = jv4a2(document["location"]["href"], '');
	$.ajax({
		url: currentUrl,
		beforeSend: function() {
			$('main').append('<div class="ajax_loading_body"><div class="spinner"><div class="double-bounce1"></div><div class="double-bounce2"></div></div></div>');
		},
		timeout: 5000,
		error: function() {
			$('.ajax_loading_body').remove();
			location["href"] = url;
		},
		success: function(data) {
			document.title = $(data).filter("title").text();
			$("main").replaceWith($(data).find("main"));
			$('main').append('<div class="ajax_loading_body"><div class="spinner"><div class="double-bounce1"></div><div class="double-bounce2"></div></div></div>');
			if (typeof _hmt != "undefined") {
				_hmt.push(['_trackPageview', targetUrl]);
			}
		},
		complete: function() {
			$('.ajax_loading_body').remove();
			init();
		}
	});
})

function jv4a2(jv1c9, jv1f5) {
	var jvd5d = new Array();
	jvd5d = jv1c9["split"]('?');
	if (jvd5d["length"] == 0x1) {
		if (jv1c9["indexOf"]('#') != -0x1) {
			jvd5d = jv1c9["split"]('#');
			return jvd5d[0x0] + '?' + jv1f5 + '#' + jvd5d[0x1]
		};
		return jv1c9 + '?' + jv1f5
	} else {
		if (jv1c9["indexOf"](jv1f5) != -0x1) return jv1c9;
		return jvd5d[0x0] + '?' + jv1f5 + '&' + jvd5d[0x1]
	}
};