<div class="bugxia-comment">
	<div class="comments single-coment-box">
		<?php
		if(!comments_open()){
			echo '<h2>评论关闭</h2>';
			return;
		}
		if (post_password_required()){
			echo '<h2>此文章带有密码</h2>';
			return;
		}
		if (have_comments()){
			echo '<h2>';
			comments_number();
			echo '</h2>';
			echo '<div class="am-comments-list am-comments-list-flip">';
			wp_list_comments('type=comment&callback=bugxia_comments');
			echo '</div>';
		}
		?>
	</div>
	<div class="page-navigator">
		<?php paginate_comments_links('prev_text=<&next_text=>'); ?>
	</div>
	<div id="respond" class="comment-respond comment-form am-panel am-panel-default">
		<div class="am-panel-hd">评论（*号为必填项）<span><?php cancel_comment_reply_link( '关闭回复' ); ?></span></div>
		<form class="am-form am-g am-panel-bd" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
			
			<fieldset>
				<?php if(!is_user_logged_in()) {?>
				<div class="am-form-group am-u-sm-4 blog-clear-left">
				<input type="text" class="" id="author" name="author" placeholder="名字*" value="<?php echo esc_attr( $commenter['comment_author'] );?>">
				</div>
				<div class="am-form-group am-u-sm-4">
				<input type="email" class="" id="email" name="email" placeholder="邮箱*" value="<?php echo esc_attr( $commenter['comment_author_email'] );?>">
				</div>

				<div class="am-form-group am-u-sm-4 blog-clear-right">
				<input type="text" class="" id="url" name="url" placeholder="网站" value="<?php echo esc_attr( $commenter['comment_author_url'] );?>">
				</div>
				<? } ?>
				<div id="smileBox"><i class="am-icon-smile-o insertSmileFace"></i></div>
				<div class="smileBox">
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/erha.png" title="二哈"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/doge.png" title="doge"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/xixi.png" title="嘻嘻"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/xiaoku.png" title="笑哭"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/punch.png" title="嘴锤"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/meng.png" title="萌"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/liezui.png" title="咧嘴"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/kun.png" title="困"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/ku.png" title="哭"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/koubi.png" title="抠鼻"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/keai.png" title="可爱"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/jingya.png" title="惊讶"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/han.png" title="汗"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/haixiu.png" title="害羞"></a>
					<a class="smileface"><img src="<?php echo get_template_directory_uri(); ?>/asset/img/smilies/daxiao.png" title="大笑"></a>
				</div>
				<div class="am-form-group">
					<textarea class="" rows="5" id="comment" name="comment" placeholder="一字千金"></textarea>
				</div>
				<?php comment_id_fields(); ?>
				<?php do_action('comment_form', $post->ID); ?>
				<div class="submitBtn">
					<button type="submit" id="submit" name="submit" class="am-btn am-btn-success">发表评论</button>
				</div>
			</fieldset>
		</form>
	</div>
</div>
