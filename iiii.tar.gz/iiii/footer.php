﻿<footer class="blog-footer" role="contentinfo">
	<div class="am-g am-g-fixed blog-fixed am-u-sm-centered footer-beian">
		<div class="am-u-sm-12 blog-text-center">
			<span><a href="https://www.miitbeian.gov.cn/" target="_blank"><?php echo get_option( 'zh_cn_l10n_icp_num' );?></a></span>		<span><a href="https://cn.wordpress.org" target="_blank" rel="nofollow"></a></span>

                            <div>
<span id="timeDate">载入天数...</span><span id="times">载入时分秒...</span>
<script>
    var now = new Date();
    function createtime() {
        var grt= new Date("08/08/2018 08:08:08");
        now.setTime(now.getTime()+250);
        days = (now - grt ) / 1000 / 60 / 60 / 24; dnum = Math.floor(days);
        hours = (now - grt ) / 1000 / 60 / 60 - (24 * dnum); hnum = Math.floor(hours);
        if(String(hnum).length ==1 ){hnum = "0" + hnum;} minutes = (now - grt ) / 1000 /60 - (24 * 60 * dnum) - (60 * hnum);
        mnum = Math.floor(minutes); if(String(mnum).length ==1 ){mnum = "0" + mnum;}
        seconds = (now - grt ) / 1000 - (24 * 60 * 60 * dnum) - (60 * 60 * hnum) - (60 * mnum);
        snum = Math.round(seconds); if(String(snum).length ==1 ){snum = "0" + snum;}
        document.getElementById("timeDate").innerHTML = "本站已连续运行 "+dnum+" 天 ";
        document.getElementById("times").innerHTML = hnum + " 小时 " + mnum + " 分 " + snum + " 秒";
    }
setInterval("createtime()",250);
</script>
</div>
			<span>
			<span class="baidu_script">
				<script>
				var _hmt = _hmt || [];
				(function() {
				  var hm = document.createElement("script");
				  hm.src = "https://hm.baidu.com/hm.js?c78f27744c3d61a47098c1745dce6afb";
				  var s = document.getElementsByTagName("script")[0]; 
				  s.parentNode.insertBefore(hm, s);
				})();
				</script>
			</span>
		</div>
	</div>
</footer>
<!-- /footer -->
</div>
<div data-am-widget="gotop" class="am-gotop am-gotop-fixed" >
<a href="#top" title="">
	  <i class="am-gotop-icon am-icon-arrow-up"></i>
</a>
</div>

<!-- /wrapper -->
<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/amazeui/2.7.2/js/amazeui.min.js"></script>
<?php wp_footer(); ?>
<script src="<?php echo get_template_directory_uri(); ?>/asset/js/jquery.lazyload.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/asset/js/scripts.js?v=<?php echo rand();?>"></script>
<?php if($_COOKIE["ajax_switch"]=="yes"){ ?>
<script src="<?php echo get_template_directory_uri(); ?>/asset/js/ajax-load.js?v=<?php echo rand();?>" id="ajaxJS"></script>
<?php } ?>
</body>
</html>
