<?php get_header(); ?>
<div class="container am-g am-g-fixed blog-fixed blog-content">
	<main role="main" class="am-u-md-8 am-u-sm-12">
		<section>
			<h1><?php single_cat_title(); ?> 分类下的文章</h1>
			<?php get_template_part('loop'); ?>
			<?php get_template_part('pagination'); ?>
		</section>
	</main>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
